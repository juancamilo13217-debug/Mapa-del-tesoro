const points = {
  0: {
    title: "Start",
    text: "Aquí comienza nuestra pequeña búsqueda. Hay recuerdos esperando al final del camino. ❤️",
    image: "images/punto1.jpg",
    number: "PRÓLOGO"
  },
  1: {
    title: "The First Meet",
    text: "La primera vez que te conocí, me pareciste alguien interesante y lleno de vida, creí que estabas un poco loco y que eras algo raro pero aún así, me gustaste mucho cuando te conocí un poquito más, basto con ser tú, de esa forma tan increíble y que sorprende para que me enamorara perdidamente de ti, mi Alexis.",
    image: "images/punto1.jpg",
    number: "RECUERDO I"
  },
  2: {
    title: "I love You?",
    text: "Ciertamente dude muchas veces de si te amaba o si solamente me gustabas porque tal vez y solo tal vez me sentía confundido, no pensé que fuera a gustarme un chico y menos alguien que conocí por internet, pero ahora no hay duda de que tú eres el dueño de la llave de mi corazón, detesto que estés lejos y el no poder darte un afectuoso abrazo, pero amo saber que sí te amo, que daría todo por ti y que nunca pero nunca sería capaz de dejarte",
    image: "images/punto2.jpg",
    number: "RECUERDO II"
  },
  3: {
    title: "Nerves",
    text: "Cuando pensé en decirte que te amaba, dudaba mucho de si era correcto, no porque no te amara lo suficiente ni porque estuviera confundido, ya no lo estaba, dudaba porque no sabía si tú también me amabas, amar a alguien tan intensamente y en poco tiempo ocurre muy pocas veces y eso me pasó contigo, el haberme enamorado tan fácil solo me recuerda lo fácil que eres de amar y lo increíble que es conocer la dulzura de tu bello corazón. Los nervios me consumían y el miedo a perderte me asustaba más que el mismo rechazo, porque alejarme de ti no sería fácil, aunque tampoco me imagino una vida sin ti desde que te conocí.",
    image: "images/punto3.jpg",
    number: "RECUERDO III"
  },
  4: {
    title: "Home",
    text: "Siempre he escuchado que el amor adolescente es algo pasajero que algún día se termina y toda esa ilusión queda hecha trizas, lo he vivido y también visto pero contigo no me asusta terminar herido si paso aunque sea un segundo a tu lado, pues esto es más que una eternidad llena de incertidumbre, soledad y miedo, prefiero arriesgarme a algo pasajero que quedarme amándote sin decir nada, te amo y no quiero que seas algo pasajero, quiero que seas mi pasado, presente y futuro, tú ya eres mi hogar y eso no lo cambiará nadie.",
    image: "images/punto4.jpg",
    number: "RECUERDO IV"
  },
  5: {
    title: "Alexis",
    text: "Una vida sin ti no es vida, amo reír de tus tonterías, enamorarme de tu dulzura y ver aquellos ojos que iluminan mi corazón. En el momento en que te volviste mi pareja, me prometi que no iba a arruinarlo, a actuar inmaduro o dejarme llevar por estupideces, me prometí cuidar lo nuestro porque es lo más valioso que tengo ahora, solo me importas tú y más nadie, pues tú eres todo lo que quiero en mi vida.",
    image: "images/punto5.jpg",
    number: "EL TESORO"
  }
};

const modal = document.getElementById("modal");
const modalImage = document.getElementById("modalImage");
const modalTitle = document.getElementById("modalTitle");
const modalText = document.getElementById("modalText");
const modalNumber = document.getElementById("modalNumber");
const close = document.getElementById("close");

document.querySelectorAll(".point").forEach(point => {
  point.addEventListener("click", () => {
    const data = points[point.dataset.point];
    modalImage.src = data.image;
    modalImage.alt = data.title;
    modalTitle.textContent = data.title;
    modalText.textContent = data.text;
    modalNumber.textContent = data.number;
    modal.classList.add("show");
    modal.setAttribute("aria-hidden", "false");
  });
});

function closeModal() {
  modal.classList.remove("show");
  modal.setAttribute("aria-hidden", "true");
}

close.addEventListener("click", closeModal);

modal.addEventListener("click", event => {
  if (event.target === modal) closeModal();
});

document.addEventListener("keydown", event => {
  if (event.key === "Escape") closeModal();
});
